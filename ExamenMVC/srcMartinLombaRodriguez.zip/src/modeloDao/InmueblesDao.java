package modeloDao;


public class InmueblesDao {
	
	 
	
		
}// fin de la clase
		