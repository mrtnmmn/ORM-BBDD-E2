package modeloDao;




public class InquilinosDao {
	
	
		 
}// fin de la clase
